import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
    const body = JSON.parse(event.body);

    try {
        await docClient.send(
            new PutCommand({
                TableName: "DailyChallengeScores",
                Item: {
                    challengeId: body.challengeId,
                    score: body.score,
                    username: body.username,
                    timestamp: new Date().toISOString()
                }
            })
        );

        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify({
                message: "Score saved successfully"
            })
        };
    } catch (err) {
        console.error(err);

        return {
            statusCode: 500,
            body: JSON.stringify(err)
        };
    }
};