import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {

    const challengeId =
        event.queryStringParameters?.challengeId;

    try {

        const result = await docClient.send(
            new QueryCommand({
                TableName: "DailyChallengeScores",
                KeyConditionExpression:
                    "challengeId = :id",

                ExpressionAttributeValues: {
                    ":id": challengeId
                },

                ScanIndexForward: false,
                Limit: 10
            })
        );

        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify(result.Items)
        };

    } catch (err) {

        console.error(err);

        return {
            statusCode: 500,
            body: JSON.stringify(err)
        };
    }
};